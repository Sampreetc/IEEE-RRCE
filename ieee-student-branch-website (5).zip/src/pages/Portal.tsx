import { useEffect, useMemo, useState } from "react";
import {
  BadgeCheck,
  Calendar,
  LogOut,
  Shield,
  Users,
  Cpu,
  Hash,
} from "lucide-react";
import { api } from "../backend/api";
import { useAuth } from "../backend/AuthContext";
import { IEEE, openIeeeJoin } from "../backend/ieee";
import { EVENTS, SOCIETIES, type Page } from "../data";
import type { EventRegistration, PublicStudent } from "../backend/types";

export default function Portal({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { user, logout, refresh, ready } = useAuth();
  const [tab, setTab] = useState<"overview" | "profile" | "events" | "roster">("overview");
  const [regs, setRegs] = useState<EventRegistration[]>([]);
  const [roster, setRoster] = useState<PublicStudent[]>([]);

  useEffect(() => {
    if (!ready) return;
    if (!user) {
      onNavigate("login");
      return;
    }
    setRegs(api.events.forStudent(user.id));
    setRoster(api.students.directory());
  }, [user, ready, onNavigate]);

  if (!user) return null;

  const statusColor =
    user.membershipStatus === "active"
      ? "text-emerald-300 bg-emerald-400/10"
      : user.membershipStatus === "pending"
        ? "text-amber-300 bg-amber-400/10"
        : "text-slate-300 bg-white/10";

  return (
    <section className="relative min-h-screen pt-28 pb-20">
      <div className="absolute inset-0 circuit-grid opacity-40" />
      <div className="relative mx-auto max-w-6xl px-5">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-300">
              Student portal
            </p>
            <h1 className="font-display mt-2 text-4xl text-white">Hello, {user.name.split(" ")[0]}.</h1>
            <p className="mt-2 text-slate-400">
              {user.usn} · {user.department} · {user.year} year
            </p>
          </div>
          <button
            onClick={() => {
              logout();
              onNavigate("home");
            }}
            className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-sm text-slate-300"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>

        <div className="mt-8 flex flex-wrap gap-2">
          {(
            [
              ["overview", "Overview"],
              ["profile", "Profile"],
              ["events", "My events"],
              ["roster", "Roster"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-wider ${
                tab === id ? "bg-ieee text-white" : "border border-white/10 text-slate-400"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === "overview" && (
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <div className="rounded-3xl border border-white/10 bg-[#0c1826] p-6">
              <Shield className="h-5 w-5 text-cyan-400" />
              <p className="mt-3 text-xs uppercase tracking-[0.2em] text-slate-500">Membership</p>
              <p className={`mt-2 inline-flex rounded-full px-3 py-1 text-sm font-semibold ${statusColor}`}>
                {user.membershipStatus}
              </p>
              {user.ieeeNumber && (
                <p className="mt-3 flex items-center gap-2 text-sm text-slate-300">
                  <Hash className="h-4 w-4 text-cyan-400" /> {user.ieeeNumber}
                </p>
              )}
            </div>
            <div className="rounded-3xl border border-white/10 bg-[#0c1826] p-6">
              <Calendar className="h-5 w-5 text-cyan-400" />
              <p className="mt-3 text-xs uppercase tracking-[0.2em] text-slate-500">Event seats</p>
              <p className="font-display mt-2 text-4xl text-white">{regs.length}</p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-[#0c1826] p-6">
              <Cpu className="h-5 w-5 text-cyan-400" />
              <p className="mt-3 text-xs uppercase tracking-[0.2em] text-slate-500">Societies</p>
              <p className="font-display mt-2 text-4xl text-white">{user.societies.length}</p>
            </div>

            <div className="md:col-span-3 rounded-3xl border border-white/10 bg-[#0c1826] p-6">
              <h3 className="font-display text-xl text-white">Next steps</h3>
              <ul className="mt-4 grid gap-3 text-sm text-slate-300 md:grid-cols-3">
                <li className="rounded-2xl border border-white/10 p-4">
                  {user.membershipStatus === "none"
                    ? "Apply for IEEE SB membership from the Join desk."
                    : user.membershipStatus === "pending"
                      ? "Application pending. Add your IEEE.org number under Profile to activate."
                      : "Membership active. Register for NEXUS 2026."}
                </li>
                <li className="rounded-2xl border border-white/10 p-4">
                  Pick a society chapter so officers can count you on the weekly roster.
                </li>
                <li className="rounded-2xl border border-white/10 p-4">
                  Keep your phone and USN current — that’s how we issue event stickers.
                </li>
              </ul>
              <div className="mt-5 flex flex-wrap gap-3">
                <button
                  onClick={() => onNavigate("events")}
                  className="rounded-full bg-ieee px-4 py-2 text-sm font-semibold text-white"
                >
                  Browse events
                </button>
                <button
                  onClick={() => onNavigate("membership")}
                  className="rounded-full border border-white/15 px-4 py-2 text-sm text-white"
                >
                  Membership guide
                </button>
              </div>
            </div>
          </div>
        )}

        {tab === "profile" && <ProfileForm onSaved={refresh} />}
        {tab === "events" && <MyEvents regs={regs} onNavigate={onNavigate} />}
        {tab === "roster" && <Roster list={roster} />}
      </div>
    </section>
  );
}

function ProfileForm({ onSaved }: { onSaved: () => void }) {
  const { user } = useAuth();
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const selected = useMemo(() => new Set(user?.societies ?? []), [user?.societies]);
  if (!user) return null;

  return (
    <div className="mt-8 grid gap-6 lg:grid-cols-2">
      <form
        className="grid gap-3 rounded-3xl border border-white/10 bg-[#0c1826] p-6"
        onSubmit={(e) => {
          e.preventDefault();
          const data = new FormData(e.currentTarget);
          try {
            api.students.update(user.id, {
              name: String(data.get("name")),
              phone: String(data.get("phone")),
              department: String(data.get("department")),
              year: String(data.get("year")),
              bio: String(data.get("bio")),
            });
            onSaved();
            setErr("");
            setMsg("Profile saved.");
          } catch (e2) {
            setMsg("");
            setErr(e2 instanceof Error ? e2.message : "Save failed.");
          }
        }}
      >
        <h3 className="font-display text-xl text-white">Campus profile</h3>
        <label className="grid gap-1 text-xs text-slate-400">
          Name
          <input
            name="name"
            defaultValue={user.name}
            className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
          />
        </label>
        <label className="grid gap-1 text-xs text-slate-400">
          Phone
          <input
            name="phone"
            defaultValue={user.phone}
            className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
          />
        </label>
        <div className="grid gap-3 md:grid-cols-2">
          <label className="grid gap-1 text-xs text-slate-400">
            Department
            <select
              name="department"
              defaultValue={user.department}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
            >
              {["CSE", "ECE", "EEE", "ISE", "ME", "CV"].map((d) => (
                <option key={d} className="bg-[#0c1826]">
                  {d}
                </option>
              ))}
            </select>
          </label>
          <label className="grid gap-1 text-xs text-slate-400">
            Year
            <select
              name="year"
              defaultValue={user.year}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
            >
              {["First", "Second", "Third", "Final"].map((d) => (
                <option key={d} className="bg-[#0c1826]">
                  {d}
                </option>
              ))}
            </select>
          </label>
        </div>
        <label className="grid gap-1 text-xs text-slate-400">
          Bio
          <textarea
            name="bio"
            defaultValue={user.bio}
            rows={3}
            className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
          />
        </label>
        <p className="text-xs text-slate-500">USN {user.usn} · {user.email}</p>
        {msg && <p className="text-sm text-cyan-300">{msg}</p>}
        {err && <p className="text-sm text-rose-400">{err}</p>}
        <button className="rounded-full bg-ieee py-2.5 text-sm font-semibold text-white">Save profile</button>
      </form>

      <div className="grid gap-6">
        <form
          className="rounded-3xl border border-white/10 bg-[#0c1826] p-6"
          onSubmit={(e) => {
            e.preventDefault();
            const ieee = String(new FormData(e.currentTarget).get("ieee"));
            try {
              api.students.activate(user.id, ieee);
              onSaved();
              setErr("");
              setMsg("Membership activated.");
            } catch (e2) {
              setMsg("");
              setErr(e2 instanceof Error ? e2.message : "Could not activate.");
            }
          }}
        >
          <h3 className="font-display text-xl text-white">IEEE.org member number</h3>
          <p className="mt-1 text-sm text-slate-400">
            Pay student dues on ieee.org, then paste the 8–10 digit number from myIEEE to activate STB20210.
          </p>
          <input
            name="ieee"
            defaultValue={user.ieeeNumber}
            placeholder="8–10 digit number"
            className="mt-4 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
          />
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={openIeeeJoin}
              className="rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white"
            >
              Join on IEEE.org
            </button>
            <a
              href={IEEE.myIeee}
              target="_blank"
              rel="noreferrer"
              className="rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white"
            >
              Open myIEEE
            </a>
            <button className="rounded-full bg-gradient-to-r from-ieee to-cyan-400 px-5 py-2.5 text-sm font-semibold text-white">
              Activate membership
            </button>
          </div>
        </form>

        <form
          className="rounded-3xl border border-white/10 bg-[#0c1826] p-6"
          onSubmit={(e) => {
            e.preventDefault();
            const boxes = Array.from(
              e.currentTarget.querySelectorAll<HTMLInputElement>("input[name=society]:checked"),
            ).map((el) => el.value);
            api.students.update(user.id, { societies: boxes });
            onSaved();
            setMsg("Societies updated.");
          }}
        >
          <h3 className="font-display text-xl text-white">Chapter opt-in</h3>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {SOCIETIES.map((s) => (
              <label key={s.id} className="flex items-center gap-2 text-sm text-slate-300">
                <input
                  type="checkbox"
                  name="society"
                  value={s.id}
                  defaultChecked={selected.has(s.id)}
                  className="accent-cyan-400"
                />
                {s.short}
              </label>
            ))}
          </div>
          <button className="mt-4 rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white">
            Save societies
          </button>
        </form>
      </div>
    </div>
  );
}

function MyEvents({
  regs,
  onNavigate,
}: {
  regs: EventRegistration[];
  onNavigate: (p: Page) => void;
}) {
  return (
    <div className="mt-8 rounded-3xl border border-white/10 bg-[#0c1826] p-6">
      <h3 className="font-display text-xl text-white">Registered seats</h3>
      {regs.length === 0 ? (
        <p className="mt-4 text-sm text-slate-400">
          No seats yet.{" "}
          <button onClick={() => onNavigate("events")} className="text-cyan-300">
            Open the calendar
          </button>
          .
        </p>
      ) : (
        <ul className="mt-4 divide-y divide-white/5">
          {regs.map((r) => {
            const ev = EVENTS.find((e) => e.id === r.eventId);
            return (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
                <div>
                  <p className="text-white">{r.eventTitle}</p>
                  <p className="text-xs text-slate-500">
                    {ev?.date} · {ev?.venue}
                  </p>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-cyan-400/10 px-3 py-1 text-xs text-cyan-300">
                  <BadgeCheck className="h-3.5 w-3.5" /> Confirmed
                </span>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function Roster({ list }: { list: PublicStudent[] }) {
  return (
    <div className="mt-8 rounded-3xl border border-white/10 bg-[#0c1826] p-6">
      <div className="flex items-center gap-2">
        <Users className="h-5 w-5 text-cyan-400" />
        <h3 className="font-display text-xl text-white">Campus roster</h3>
      </div>
      <p className="mt-1 text-sm text-slate-400">Students with a pending or active IEEE SB application.</p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        {list.map((s) => (
          <div key={s.id} className="rounded-2xl border border-white/10 p-4">
            <p className="font-medium text-white">{s.name}</p>
            <p className="text-xs text-slate-500">
              {s.usn} · {s.department} · {s.year}
            </p>
            <p className="mt-2 text-[11px] uppercase tracking-[0.18em] text-cyan-300">{s.membershipStatus}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
