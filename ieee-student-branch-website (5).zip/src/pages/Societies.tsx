import PageHero from "../components/PageHero";
import { SOCIETIES } from "../data";

export default function Societies() {
  return (
    <>
      <PageHero
        kicker="Societies & affinity"
        title="Technical homes inside the branch."
        text="IEEE membership is the door. Societies are the rooms. Pick one — or three — and show up to the weekly build."
      />
      <section className="py-16">
        <div className="mx-auto grid max-w-7xl gap-6 px-5 lg:grid-cols-2">
          {SOCIETIES.map((s) => (
            <article
              key={s.id}
              className="overflow-hidden rounded-3xl border border-white/10 bg-[#0c1826]"
            >
              <div className="h-1.5 w-full" style={{ background: s.color }} />
              <div className="p-7">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.28em] text-slate-500">IEEE</p>
                    <h3 className="font-display mt-1 text-2xl text-white">{s.name}</h3>
                  </div>
                  <span
                    className="rounded-2xl px-3 py-1 font-display text-sm font-bold text-white"
                    style={{ background: s.color }}
                  >
                    {s.short}
                  </span>
                </div>
                <p className="mt-4 leading-relaxed text-slate-400">{s.desc}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {s.focus.map((f) => (
                    <span
                      key={f}
                      className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-300"
                    >
                      {f}
                    </span>
                  ))}
                </div>
                <p className="mt-5 text-xs uppercase tracking-[0.2em] text-cyan-300">
                  {s.members} active members on campus
                </p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
