import { Calendar, Clock, MapPin, Users, X, CheckCircle2 } from "lucide-react";
import { useMemo, useState, type FormEvent } from "react";
import PageHero from "../components/PageHero";
import { EVENTS, type EventItem, type Page } from "../data";
import { api } from "../backend/api";
import { useAuth } from "../backend/AuthContext";

const filters = ["All", "Upcoming", "Past", "Hackathon", "Workshop", "Lecture", "Visit", "Summit", "Contest"] as const;

export default function Events({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { user } = useAuth();
  const [filter, setFilter] = useState<(typeof filters)[number]>("Upcoming");
  const [active, setActive] = useState<EventItem | null>(null);
  const [registered, setRegistered] = useState(false);
  const [error, setError] = useState("");

  const list = useMemo(() => {
    return EVENTS.filter((e) => {
      if (filter === "All") return true;
      if (filter === "Upcoming") return e.status === "upcoming";
      if (filter === "Past") return e.status === "past";
      return e.type === filter;
    });
  }, [filter]);

  return (
    <>
      <PageHero
        kicker="Events"
        title="Workshops, lectures, and 36-hour builds."
        text="Everything on this calendar is run by student officers with a faculty sign-off. Register early — hardware seats go first."
      />

      <section className="py-14">
        <div className="mx-auto max-w-7xl px-5">
          <div className="flex flex-wrap gap-2">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-wider ${
                  filter === f ? "bg-ieee text-white" : "border border-white/10 text-slate-400"
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {list.map((e) => (
              <article
                key={e.id}
                className="flex flex-col overflow-hidden rounded-3xl border border-white/10 bg-[#0c1826] sm:flex-row"
              >
                <img src={e.image} alt={e.title} className="h-48 w-full object-cover sm:h-auto sm:w-48" />
                <div className="flex flex-1 flex-col p-6">
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-cyan-400/15 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-cyan-300">
                      {e.type}
                    </span>
                    {e.status === "past" && (
                      <span className="text-[10px] uppercase tracking-wider text-slate-500">Archived</span>
                    )}
                  </div>
                  <h3 className="font-display mt-2 text-xl text-white">{e.title}</h3>
                  <p className="mt-3 line-clamp-2 text-sm text-slate-400">{e.desc}</p>
                  <p className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                    <Calendar className="h-3.5 w-3.5" /> {e.date}
                    {e.end ? ` – ${e.end}` : ""} · <MapPin className="h-3.5 w-3.5" /> {e.venue}
                  </p>
                  <button
                    onClick={() => {
                      setActive(e);
                      setError("");
                      setRegistered(
                        api.events.isRegistered(e.id, user?.id, user?.email),
                      );
                    }}
                    className="mt-4 self-start text-sm font-semibold text-cyan-300"
                  >
                    {e.status === "upcoming" ? "Details & register →" : "View recap →"}
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {active && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <button className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setActive(null)} />
          <div className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-white/10 bg-[#0c1826]">
            <img src={active.image} alt="" className="h-52 w-full object-cover" />
            <button
              onClick={() => setActive(null)}
              className="absolute top-4 right-4 rounded-full bg-black/50 p-2 text-white"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="p-7">
              <p className="text-xs uppercase tracking-[0.2em] text-cyan-300">{active.type}</p>
              <h3 className="font-display mt-2 text-3xl text-white">{active.title}</h3>
              <div className="mt-4 grid gap-2 text-sm text-slate-400">
                <p className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-cyan-400" /> {active.date}
                  {active.end ? ` – ${active.end}` : ""}
                </p>
                <p className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-cyan-400" /> {active.time}
                </p>
                <p className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-cyan-400" /> {active.venue}
                </p>
                {active.seats && (
                  <p className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-cyan-400" /> {active.seats}
                  </p>
                )}
              </div>
              <p className="mt-4 leading-relaxed text-slate-300">{active.desc}</p>

              {active.status === "upcoming" &&
                (registered ? (
                  <div className="mt-6 flex items-center gap-2 rounded-2xl bg-cyan-400/10 p-4 text-sm text-cyan-200">
                    <CheckCircle2 className="h-5 w-5" /> Seat reserved. Check your inbox for the ICS file.
                  </div>
                ) : (
                  <form
                    className="mt-6 grid gap-3"
                    onSubmit={(e: FormEvent<HTMLFormElement>) => {
                      e.preventDefault();
                      if (!user) {
                        onNavigate("login");
                        return;
                      }
                      const data = new FormData(e.currentTarget);
                      try {
                        api.events.register({
                          studentId: user.id,
                          eventId: active.id,
                          eventTitle: active.title,
                          name: String(data.get("name") || user.name),
                          email: String(data.get("email") || user.email),
                        });
                        setError("");
                        setRegistered(true);
                      } catch (err) {
                        setError(err instanceof Error ? err.message : "Could not register.");
                      }
                    }}
                  >
                    {!user && (
                      <p className="rounded-xl border border-amber-400/20 bg-amber-400/10 px-3 py-2 text-sm text-amber-100">
                        Sign in to the student portal to hold a seat.
                      </p>
                    )}
                    <input
                      name="name"
                      required
                      defaultValue={user?.name ?? ""}
                      placeholder="Full name"
                      className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
                    />
                    <input
                      name="email"
                      required
                      type="email"
                      defaultValue={user?.email ?? ""}
                      placeholder="College email"
                      className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
                    />
                    {error && <p className="text-sm text-rose-400">{error}</p>}
                    <button className="rounded-full bg-gradient-to-r from-ieee to-cyan-400 py-3 text-sm font-semibold text-white">
                      {user ? "Register for this event" : "Sign in to register"}
                    </button>
                  </form>
                ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
