import { useState, type InputHTMLAttributes } from "react";
import { useAuth } from "../backend/AuthContext";
import type { Page } from "../data";

export default function Register({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { register } = useAuth();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <section className="relative flex min-h-screen items-center justify-center px-5 pt-28 pb-16">
      <div className="absolute inset-0 circuit-grid opacity-50" />
      <div className="relative w-full max-w-xl rounded-3xl border border-cyan-400/20 bg-[#0c1826] p-8">
        <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-300">Student roster</p>
        <h1 className="font-display mt-2 text-3xl text-white">Create your account</h1>
        <p className="mt-2 text-sm text-slate-400">
          This is the campus IEEE account — not ieee.org. After signup you can apply for membership
          and register for events.
        </p>

        <form
          className="mt-6 grid gap-3 md:grid-cols-2"
          onSubmit={async (e) => {
            e.preventDefault();
            const form = e.currentTarget;
            const data = new FormData(form);
            setError("");
            setBusy(true);
            try {
              await register({
                name: String(data.get("name")),
                email: String(data.get("email")),
                password: String(data.get("password")),
                usn: String(data.get("usn")),
                phone: String(data.get("phone")),
                department: String(data.get("department")),
                year: String(data.get("year")),
              });
              onNavigate("portal");
            } catch (err) {
              setError(err instanceof Error ? err.message : "Could not create account.");
            } finally {
              setBusy(false);
            }
          }}
        >
          <Field name="name" label="Full name" placeholder="Your name" required />
          <Field name="email" type="email" label="College email" placeholder="usn@rrce.org" required />
          <Field name="usn" label="USN / Roll" placeholder="1RR23CS000" required />
          <Field name="phone" label="Phone" placeholder="+91" required />
          <label className="grid gap-1 text-xs text-slate-400">
            Department
            <select
              name="department"
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
            >
              {["CSE", "ECE", "EEE", "ISE", "ME", "CV"].map((d) => (
                <option key={d} className="bg-[#0c1826]">
                  {d}
                </option>
              ))}
            </select>
          </label>
          <label className="grid gap-1 text-xs text-slate-400">
            Year
            <select
              name="year"
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none"
            >
              {["First", "Second", "Third", "Final"].map((d) => (
                <option key={d} className="bg-[#0c1826]">
                  {d}
                </option>
              ))}
            </select>
          </label>
          <div className="md:col-span-2">
            <Field name="password" type="password" label="Password" placeholder="Min. 6 characters" required />
          </div>
          {error && <p className="md:col-span-2 text-sm text-rose-400">{error}</p>}
          <button
            disabled={busy}
            className="md:col-span-2 mt-2 rounded-full bg-gradient-to-r from-ieee to-cyan-400 py-3 text-sm font-semibold text-white disabled:opacity-60"
          >
            {busy ? "Creating…" : "Create student account"}
          </button>
        </form>

        <p className="mt-5 text-center text-sm text-slate-400">
          Already on the roster?{" "}
          <button onClick={() => onNavigate("login")} className="font-semibold text-cyan-300">
            Sign in
          </button>
        </p>
      </div>
    </section>
  );
}

function Field({
  label,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string; name: string }) {
  return (
    <label className="grid gap-1 text-xs text-slate-400">
      {label}
      <input
        {...props}
        className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-600 focus:border-cyan-400/50"
      />
    </label>
  );
}
