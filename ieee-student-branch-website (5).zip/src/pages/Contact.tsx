import { Mail, MapPin, Phone, Clock, CheckCircle2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import PageHero from "../components/PageHero";
import { api } from "../backend/api";
import { useAuth } from "../backend/AuthContext";

export default function Contact() {
  const { user } = useAuth();
  const [sent, setSent] = useState(false);

  return (
    <>
      <PageHero
        kicker="Contact"
        title="Write to the branch. Walk into C-214."
        text="Membership desk on Fridays. Counselor hours on Tuesdays. The rest of the week we are in the hardware studio or the CS lab."
      />

      <section className="py-16">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 lg:grid-cols-2">
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              { icon: MapPin, t: "Campus", d: "No. 14, Ramohalli Cross, Kumbalgodu, Mysore Road, Bengaluru 560074" },
              { icon: Mail, t: "Email", d: "ieee@rrce.org · chair.ieee@rrce.org" },
              { icon: Phone, t: "Phone", d: "+91 80 2843 7375" },
              { icon: Clock, t: "Desk hours", d: "Fri 16:00–18:00 · Counselor Tue 15:00–16:00" },
            ].map((c) => (
              <div key={c.t} className="rounded-3xl border border-white/10 bg-[#0c1826] p-6">
                <c.icon className="h-5 w-5 text-cyan-400" />
                <h3 className="font-display mt-3 text-white">{c.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{c.d}</p>
              </div>
            ))}
            <div className="sm:col-span-2 overflow-hidden rounded-3xl border border-white/10">
              <iframe
                title="RRCE campus map"
                className="h-64 w-full grayscale invert-[0.88] contrast-125"
                src="https://www.openstreetmap.org/export/embed.html?bbox=77.43%2C12.87%2C77.50%2C12.92&layer=mapnik"
              />
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-[#0c1826] p-8">
            {sent ? (
              <div className="flex h-full flex-col items-center justify-center py-16 text-center">
                <CheckCircle2 className="h-12 w-12 text-cyan-400" />
                <h3 className="font-display mt-4 text-2xl text-white">Message received</h3>
                <p className="mt-2 text-sm text-slate-400">The secretary will reply from ieee@rrce.org.</p>
              </div>
            ) : (
              <form
                className="grid gap-4"
                onSubmit={(e: FormEvent<HTMLFormElement>) => {
                  e.preventDefault();
                  const data = new FormData(e.currentTarget);
                  api.messages.create({
                    name: String(data.get("name")),
                    email: String(data.get("email")),
                    topic: String(data.get("topic")),
                    body: String(data.get("body")),
                  });
                  setSent(true);
                }}
              >
                <h3 className="font-display text-2xl text-white">Send a note</h3>
                <input
                  name="name"
                  required
                  defaultValue={user?.name ?? ""}
                  placeholder="Name"
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none focus:border-cyan-400/50"
                />
                <input
                  name="email"
                  required
                  type="email"
                  defaultValue={user?.email ?? ""}
                  placeholder="Email"
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none focus:border-cyan-400/50"
                />
                <select
                  name="topic"
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none"
                >
                  <option className="bg-[#0c1826]">Membership</option>
                  <option className="bg-[#0c1826]">Event partnership</option>
                  <option className="bg-[#0c1826]">Speaker proposal</option>
                  <option className="bg-[#0c1826]">Press / media</option>
                </select>
                <textarea
                  name="body"
                  required
                  rows={5}
                  placeholder="How can the branch help?"
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none focus:border-cyan-400/50"
                />
                <button className="rounded-full bg-gradient-to-r from-ieee to-cyan-400 py-3 text-sm font-semibold text-white">
                  Send message
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
