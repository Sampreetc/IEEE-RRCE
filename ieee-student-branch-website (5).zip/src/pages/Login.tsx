import { useState } from "react";
import { useAuth } from "../backend/AuthContext";
import type { Page } from "../data";

export default function Login({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { login } = useAuth();
  const [email, setEmail] = useState("student@rrce.org");
  const [password, setPassword] = useState("ieee2026");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <section className="relative flex min-h-screen items-center justify-center px-5 pt-28 pb-16">
      <div className="absolute inset-0 circuit-grid opacity-50" />
      <div className="relative w-full max-w-md rounded-3xl border border-cyan-400/20 bg-[#0c1826] p-8">
        <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-300">Student portal</p>
        <h1 className="font-display mt-2 text-3xl text-white">Sign in</h1>
        <p className="mt-2 text-sm text-slate-400">IEEE SB RRCE roster · campus accounts only.</p>

        <form
          className="mt-6 grid gap-3"
          onSubmit={async (e) => {
            e.preventDefault();
            setError("");
            setBusy(true);
            try {
              await login(email, password);
              onNavigate("portal");
            } catch (err) {
              setError(err instanceof Error ? err.message : "Login failed.");
            } finally {
              setBusy(false);
            }
          }}
        >
          <label className="grid gap-1 text-xs text-slate-400">
            Email
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/50"
            />
          </label>
          <label className="grid gap-1 text-xs text-slate-400">
            Password
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/50"
            />
          </label>
          {error && <p className="text-sm text-rose-400">{error}</p>}
          <button
            disabled={busy}
            className="mt-2 rounded-full bg-gradient-to-r from-ieee to-cyan-400 py-3 text-sm font-semibold text-white disabled:opacity-60"
          >
            {busy ? "Signing in…" : "Enter portal"}
          </button>
        </form>

        <div className="mt-5 rounded-2xl border border-white/10 bg-white/5 p-4 text-xs text-slate-400">
          Demo student: <span className="text-cyan-300">student@rrce.org</span> /{" "}
          <span className="text-cyan-300">ieee2026</span>
        </div>

        <p className="mt-5 text-center text-sm text-slate-400">
          New to the branch?{" "}
          <button onClick={() => onNavigate("register")} className="font-semibold text-cyan-300">
            Create a student account
          </button>
        </p>
      </div>
    </section>
  );
}
