import PageHero from "../components/PageHero";
import { CORE, TEAM } from "../data";

export default function Team() {
  return (
    <>
      <PageHero
        kicker="People"
        title="Execom 2025–26 and the core that ships."
        text="Officers are elected each August. Core leads are appointed on contribution. If you want a title, start by showing up."
      />

      <section className="py-16">
        <div className="mx-auto max-w-7xl px-5">
          <h2 className="font-display text-2xl text-white">Executive committee</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {TEAM.map((m) => (
              <article
                key={m.name}
                className="overflow-hidden rounded-3xl border border-white/10 bg-[#0c1826] text-center"
              >
                <img src={m.img} alt={m.name} className="h-64 w-full object-cover object-top" />
                <div className="p-5">
                  <h3 className="font-display text-lg text-white">{m.name}</h3>
                  <p className="text-sm text-cyan-300">{m.role}</p>
                  <p className="mt-1 text-xs text-slate-500">{m.dept}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="mx-auto max-w-7xl px-5">
          <h2 className="font-display text-2xl text-white">Core team</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {CORE.map((m) => (
              <div
                key={m.name}
                className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-ieee to-cyan-400 font-display text-sm font-bold text-white">
                  {m.initials}
                </div>
                <div>
                  <p className="font-medium text-white">{m.name}</p>
                  <p className="text-xs text-slate-400">{m.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
