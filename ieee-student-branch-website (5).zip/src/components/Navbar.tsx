import { Menu, X, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import Logo from "./Logo";
import { NAV, type Page } from "../data";
import { useAuth } from "../backend/AuthContext";

export default function Navbar({
  page,
  onNavigate,
  onJoin,
}: {
  page: Page;
  onNavigate: (p: Page) => void;
  onJoin: () => void;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [page]);

  const initials = user
    ? user.name
        .split(" ")
        .map((p) => p[0])
        .slice(0, 2)
        .join("")
        .toUpperCase()
    : "";

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || open ? "glass shadow-lg shadow-black/20" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-6">
        <button onClick={() => onNavigate("home")} className="cursor-pointer" aria-label="Home">
          <Logo />
        </button>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`rounded-full px-3.5 py-2 text-[13px] font-medium tracking-wide transition ${
                page === item.id
                  ? "bg-white/10 text-white"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {user ? (
            <button
              onClick={() => onNavigate("portal")}
              className="hidden items-center gap-2 rounded-full border border-cyan-400/30 bg-white/5 py-1 pr-3 pl-1 text-sm font-semibold text-white md:inline-flex"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ieee text-xs">
                {initials}
              </span>
              Portal
            </button>
          ) : (
            <button
              onClick={() => onNavigate("login")}
              className="hidden rounded-full border border-white/15 px-4 py-2 text-sm font-semibold text-white md:inline-flex"
            >
              Student login
            </button>
          )}
          <button
            onClick={onJoin}
            className="hidden items-center gap-2 rounded-full bg-gradient-to-r from-ieee to-cyan-400 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-cyan-500/20 transition hover:brightness-110 md:inline-flex"
          >
            <Sparkles className="h-4 w-4" />
            Join IEEE
          </button>
          <button
            className="rounded-lg p-2 text-white lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {open && (
        <div className="glass border-t border-white/5 px-4 py-4 lg:hidden">
          <div className="grid gap-1">
            {NAV.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`rounded-xl px-4 py-3 text-left text-sm font-medium ${
                  page === item.id ? "bg-ieee/30 text-white" : "text-slate-300"
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => onNavigate(user ? "portal" : "login")}
              className="rounded-xl px-4 py-3 text-left text-sm font-medium text-cyan-300"
            >
              {user ? "Student portal" : "Student login"}
            </button>
            <button
              onClick={onJoin}
              className="mt-2 rounded-xl bg-gradient-to-r from-ieee to-cyan-400 px-4 py-3 text-sm font-semibold text-white"
            >
              Become a member
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
