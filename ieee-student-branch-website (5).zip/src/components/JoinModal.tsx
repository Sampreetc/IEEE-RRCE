import { X, CheckCircle2 } from "lucide-react";
import { useEffect, useState, type FormEvent, type InputHTMLAttributes } from "react";
import { api } from "../backend/api";
import { useAuth } from "../backend/AuthContext";
import { openIeeeJoin } from "../backend/ieee";
import type { Page } from "../data";

export default function JoinModal({
  open,
  onClose,
  onNavigate,
}: {
  open: boolean;
  onClose: () => void;
  onNavigate: (p: Page) => void;
}) {
  const { user, register, refresh } = useAuth();
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setSent(false);
      setError("");
    }
  }, [open]);

  if (!open) return null;

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    const data = new FormData(e.currentTarget);
    const why = String(data.get("why") || "");
    try {
      let studentId = user?.id;
      if (!studentId) {
        const created = await register({
          name: String(data.get("name")),
          email: String(data.get("email")),
          password: String(data.get("password")),
          usn: String(data.get("usn")),
          phone: String(data.get("phone")),
          department: String(data.get("department")),
          year: String(data.get("year")),
        });
        studentId = created.id;
      }
      api.membership.apply(studentId, why);
      refresh();
      setSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not submit.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
      <button className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-cyan-400/20 bg-[#0c1826] shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/5 px-6 py-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-cyan-300">IEEE SB RRCE</p>
            <h3 className="font-display text-xl font-semibold text-white">Membership desk</h3>
          </div>
          <button onClick={onClose} className="rounded-full p-2 text-slate-400 hover:bg-white/5">
            <X className="h-5 w-5" />
          </button>
        </div>

        {sent ? (
          <div className="px-6 py-12 text-center">
            <CheckCircle2 className="mx-auto h-12 w-12 text-cyan-400" />
            <h4 className="font-display mt-4 text-2xl text-white">Campus roster saved</h4>
            <p className="mt-2 text-sm text-slate-400">
              Next step is on the official IEEE website. Join as a Student Member, then paste your
              IEEE number in the RRCE portal.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button
                onClick={openIeeeJoin}
                className="rounded-full bg-gradient-to-r from-ieee to-cyan-400 px-5 py-2 text-sm font-semibold text-white"
              >
                Join on IEEE.org
              </button>
              <button
                onClick={() => {
                  setSent(false);
                  onClose();
                  onNavigate("portal");
                }}
                className="rounded-full bg-white/10 px-5 py-2 text-sm font-semibold text-white"
              >
                Open student portal
              </button>
            </div>
          </div>
        ) : (
          <form className="grid gap-3 px-6 py-6" onSubmit={submit}>
            {user ? (
              <p className="rounded-xl border border-cyan-400/20 bg-cyan-400/10 px-3 py-2 text-sm text-cyan-100">
                Applying as <strong>{user.name}</strong> ({user.usn}).
              </p>
            ) : (
              <>
                <div className="grid gap-3 md:grid-cols-2">
                  <Field name="name" label="Full name" placeholder="Your name" required />
                  <Field name="email" type="email" label="Email" placeholder="usn@rrce.org" required />
                  <Field name="usn" label="USN / Roll" placeholder="1RR23CS000" required />
                  <Field name="phone" label="Phone" placeholder="+91" required />
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  <label className="grid gap-1 text-xs text-slate-400">
                    Department
                    <select
                      name="department"
                      className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/50"
                    >
                      {["CSE", "ECE", "EEE", "ISE", "ME", "CV"].map((d) => (
                        <option key={d} className="bg-[#0c1826]">
                          {d}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="grid gap-1 text-xs text-slate-400">
                    Year
                    <select
                      name="year"
                      className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/50"
                    >
                      {["First", "Second", "Third", "Final"].map((d) => (
                        <option key={d} className="bg-[#0c1826]">
                          {d}
                        </option>
                      ))}
                    </select>
                  </label>
                </div>
                <Field name="password" type="password" label="Portal password" placeholder="Min. 6 characters" required />
              </>
            )}
            <label className="grid gap-1 text-xs text-slate-400">
              Why IEEE?
              <textarea
                name="why"
                required
                rows={3}
                className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/50"
                placeholder="Tell us what you want to build, research, or lead."
              />
            </label>
            {error && <p className="text-sm text-rose-400">{error}</p>}
            <button
              type="submit"
              disabled={busy}
              className="mt-2 rounded-full bg-gradient-to-r from-ieee to-cyan-400 py-3 text-sm font-semibold text-white disabled:opacity-60"
            >
              {busy ? "Saving…" : "Submit application"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string; name: string }) {
  return (
    <label className="grid gap-1 text-xs text-slate-400">
      {label}
      <input
        {...props}
        className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-600 focus:border-cyan-400/50"
      />
    </label>
  );
}
