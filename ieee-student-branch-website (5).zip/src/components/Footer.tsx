import { Mail, MapPin, Phone } from "lucide-react";
import Logo from "./Logo";
import { NAV, type Page } from "../data";
import { COLLEGE } from "../backend/college";
import { IEEE_LINKS } from "../backend/ieee";

const socials = [
  {
    label: "Instagram",
    path: "M7 3h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4zm5 5.2A3.8 3.8 0 1 0 15.8 12 3.8 3.8 0 0 0 12 8.2zM17.6 6.3a.9.9 0 1 0 .9.9.9.9 0 0 0-.9-.9z",
  },
  {
    label: "LinkedIn",
    path: "M6.5 9H3.7v11.3h2.8zm-.1-4.9a1.64 1.64 0 1 0 0 3.28 1.64 1.64 0 0 0 0-3.28zM20.3 13.4c0-3.3-1.8-4.8-4.1-4.8a3.5 3.5 0 0 0-3.2 1.8h-.1V9H10.2v11.3h2.8v-5.6c0-1.5.3-2.9 2.1-2.9s1.8 1.7 1.8 3v5.5h2.8z",
  },
  {
    label: "YouTube",
    path: "M22.5 7.2a3 3 0 0 0-2.1-2.1C18.6 4.7 12 4.7 12 4.7s-6.6 0-8.4.4A3 3 0 0 0 1.5 7.2 31 31 0 0 0 1.1 12a31 31 0 0 0 .4 4.8 3 3 0 0 0 2.1 2.1c1.8.4 8.4.4 8.4.4s6.6 0 8.4-.4a3 3 0 0 0 2.1-2.1 31 31 0 0 0 .4-4.8 31 31 0 0 0-.4-4.8zM10 15.5v-7l6 3.5z",
  },
  {
    label: "GitHub",
    path: "M12 2a10 10 0 0 0-3.2 19.5c.5.1.7-.2.7-.5v-1.7c-2.8.6-3.4-1.2-3.4-1.2-.5-1.1-1.1-1.4-1.1-1.4-.9-.6.1-.6.1-.6 1 .1 1.5 1 1.5 1 .9 1.5 2.4 1.1 3 .8.1-.6.4-1.1.6-1.3-2.2-.3-4.6-1.1-4.6-5a3.9 3.9 0 0 1 1-2.7 3.6 3.6 0 0 1 .1-2.6s.8-.3 2.7 1a9.3 9.3 0 0 1 5 0c1.9-1.3 2.7-1 2.7-1a3.6 3.6 0 0 1 .1 2.6 3.9 3.9 0 0 1 1 2.7c0 3.9-2.4 4.7-4.6 5 .4.3.7 1 .7 2v2.9c0 .3.2.6.7.5A10 10 0 0 0 12 2z",
  },
];

export default function Footer({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <footer className="relative border-t border-cyan-400/10 bg-[#060d16]">
      <div className="gold-line h-px w-full" />
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo />
          <p className="mt-5 text-sm leading-relaxed text-slate-400">
            IEEE Student Branch {COLLEGE.stb}, {COLLEGE.name}, {COLLEGE.city}. Advancing technology
            for humanity — from the lab bench to the lecture hall.
          </p>
          <div className="mt-5 flex gap-3">
            {socials.map((s) => (
              <a
                key={s.label}
                href="#"
                onClick={(e) => e.preventDefault()}
                aria-label={s.label}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-slate-300 transition hover:border-cyan-400/40 hover:text-cyan-300"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current">
                  <path d={s.path} />
                </svg>
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-white">Explore</h3>
          <ul className="mt-4 space-y-2">
            {NAV.map((n) => (
              <li key={n.id}>
                <button
                  onClick={() => onNavigate(n.id)}
                  className="text-sm text-slate-400 transition hover:text-cyan-300"
                >
                  {n.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-white">IEEE</h3>
          <ul className="mt-4 space-y-2 text-sm text-slate-400">
            {IEEE_LINKS.slice(0, 6).map((l) => (
              <li key={l.href}>
                <a href={l.href} target="_blank" rel="noreferrer" className="transition hover:text-cyan-300">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-white">Visit</h3>
          <ul className="mt-4 space-y-3 text-sm text-slate-400">
            <li className="flex gap-2">
              <MapPin className="mt-0.5 h-4 w-4 text-cyan-400" />
              {COLLEGE.address}
            </li>
            <li className="flex gap-2">
              <Mail className="mt-0.5 h-4 w-4 text-cyan-400" />
              {COLLEGE.email}
            </li>
            <li className="flex gap-2">
              <Phone className="mt-0.5 h-4 w-4 text-cyan-400" />
              {COLLEGE.phone}
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5 py-6 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} IEEE Student Branch {COLLEGE.stb} — {COLLEGE.name}. IEEE is a
        registered trademark of The Institute of Electrical and Electronics Engineers, Inc.
      </div>
    </footer>
  );
}
