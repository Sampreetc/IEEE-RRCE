export default function PageHero({
  kicker,
  title,
  text,
}: {
  kicker: string;
  title: string;
  text: string;
}) {
  return (
    <section className="relative overflow-hidden border-b border-cyan-400/10 pt-32 pb-20">
      <div className="absolute inset-0 circuit-grid opacity-60" />
      <div className="glow-orb absolute -top-24 right-10 h-64 w-64 rounded-full bg-ieee/30" />
      <div className="relative mx-auto max-w-6xl px-5">
        <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-300">{kicker}</p>
        <h1 className="font-display mt-4 max-w-4xl text-4xl font-semibold tracking-tight text-white md:text-6xl">
          {title}
        </h1>
        <p className="mt-5 max-w-2xl text-lg leading-relaxed text-slate-400">{text}</p>
      </div>
    </section>
  );
}
