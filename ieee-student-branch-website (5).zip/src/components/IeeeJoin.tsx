import { ExternalLink } from "lucide-react";
import { IEEE, IEEE_JOIN_STEPS, openIeeeJoin } from "../backend/ieee";

export default function IeeeJoin({ compact = false }: { compact?: boolean }) {
  return (
    <div className="rounded-3xl border border-cyan-400/20 bg-[#0c1826] p-6">
      <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-cyan-300">
        Official IEEE.org
      </p>
      <h3 className="font-display mt-2 text-xl text-white">
        Membership is created on the real IEEE website.
      </h3>
      <p className="mt-2 text-sm leading-relaxed text-slate-400">
        IEEE does not allow campuses to sell membership. You join at ieee.org, then we record your
        member number on the RajaRajeswari College of Engineering student branch roster (STB20210,
        Bangalore Section).
      </p>
      {!compact && (
        <ol className="mt-5 space-y-3">
          {IEEE_JOIN_STEPS.map((s, i) => (
            <li key={s.title} className="flex gap-3 text-sm text-slate-300">
              <span className="font-display text-cyan-300">0{i + 1}</span>
              <span>
                <a href={s.href} target="_blank" rel="noreferrer" className="text-white hover:text-cyan-300">
                  {s.title}
                </a>
                <span className="block text-slate-400">{s.text}</span>
              </span>
            </li>
          ))}
        </ol>
      )}
      <div className="mt-5 flex flex-wrap gap-3">
        <button
          onClick={openIeeeJoin}
          className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-ieee to-cyan-400 px-5 py-2.5 text-sm font-semibold text-white"
        >
          Join on IEEE.org <ExternalLink className="h-4 w-4" />
        </button>
        <a
          href={IEEE.myIeee}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-2 rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white"
        >
          Open myIEEE
        </a>
      </div>
    </div>
  );
}
