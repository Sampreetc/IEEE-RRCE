export const COLLEGE = {
  name: "RajaRajeswari College of Engineering",
  short: "RRCE",
  city: "Bengaluru",
  address: "No. 14, Ramohalli Cross, Kumbalgodu, Mysore Road, Bengaluru 560074",
  email: "ieee@rrce.org",
  chairEmail: "chair.ieee@rrce.org",
  phone: "+91 80 2843 7375",
  stb: "STB20210",
  section: "IEEE Bangalore Section",
  region: "IEEE Region 10 — Asia Pacific",
  website: "https://www.rrce.org",
  affiliated: "VTU Belagavi · AICTE · NAAC A+",
  mapEmbed:
    "https://www.openstreetmap.org/export/embed.html?bbox=77.43%2C12.87%2C77.50%2C12.92&layer=mapnik",
};
