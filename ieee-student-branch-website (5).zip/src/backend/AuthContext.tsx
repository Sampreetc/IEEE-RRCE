import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api } from "./api";
import type { PublicStudent, RegisterInput } from "./types";

type AuthCtx = {
  user: PublicStudent | null;
  ready: boolean;
  login: (email: string, password: string) => Promise<PublicStudent>;
  register: (input: RegisterInput) => Promise<PublicStudent>;
  logout: () => void;
  refresh: () => void;
};

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<PublicStudent | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    api.init().then(() => {
      setUser(api.auth.me());
      setReady(true);
    });
  }, []);

  const value = useMemo<AuthCtx>(
    () => ({
      user,
      ready,
      async login(email, password) {
        const u = await api.auth.login(email, password);
        setUser(u);
        return u;
      },
      async register(input) {
        const u = await api.auth.register(input);
        setUser(u);
        return u;
      },
      logout() {
        api.auth.logout();
        setUser(null);
      },
      refresh() {
        setUser(api.auth.me());
      },
    }),
    [user, ready],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
