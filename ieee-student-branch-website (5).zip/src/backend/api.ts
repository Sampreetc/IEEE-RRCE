import type {
  ContactMessage,
  Database,
  EventRegistration,
  MembershipApp,
  PublicStudent,
  RegisterInput,
  Student,
} from "./types";
import { normalizeIeeeNumber, validateIeeeNumber } from "./ieee";

const DB_KEY = "ieee_sb_rrce_db_v1";
const SESSION_KEY = "ieee_sb_rrce_session";

function uid() {
  return crypto.randomUUID?.() ?? `id_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function empty(): Database {
  return { students: [], memberships: [], registrations: [], messages: [], seeded: false };
}

function load(): Database {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) return empty();
    return { ...empty(), ...JSON.parse(raw) } as Database;
  } catch {
    return empty();
  }
}

function save(db: Database) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

async function hashPassword(password: string) {
  const data = new TextEncoder().encode(`ieee-sb-rrce::${password}`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function publicStudent(s: Student): PublicStudent {
  const { passwordHash: _, ...rest } = s;
  return rest;
}

function sessionId() {
  return localStorage.getItem(SESSION_KEY);
}

function setSession(id: string | null) {
  if (id) localStorage.setItem(SESSION_KEY, id);
  else localStorage.removeItem(SESSION_KEY);
}

const DEMO: Array<RegisterInput & { ieeeNumber?: string; status?: Student["membershipStatus"]; societies?: string[]; bio?: string }> =
  [
    {
      name: "Diya Sharma",
      email: "student@rrce.org",
      password: "ieee2026",
      usn: "1RR23CS118",
      phone: "+91 98450 11001",
      department: "CSE",
      year: "Third",
      ieeeNumber: "98765432",
      status: "active",
      societies: ["cs", "wie"],
      bio: "CS chapter volunteer. Building the NEXUS ops desk.",
    },
    {
      name: "Rohan Mehta",
      email: "rohan@rrce.org",
      password: "ieee2026",
      usn: "1RR24EC042",
      phone: "+91 98450 11002",
      department: "ECE",
      year: "Second",
      status: "pending",
      societies: ["ras"],
      bio: "Hardware nights and RAS build crew.",
    },
    {
      name: "Anika Sen",
      email: "anika@rrce.org",
      password: "ieee2026",
      usn: "1RR22EE019",
      phone: "+91 98450 11003",
      department: "EEE",
      year: "Final",
      ieeeNumber: "97654321",
      status: "active",
      societies: ["pes", "sight"],
      bio: "PES lead for the smart-grid study circle.",
    },
  ];

let booting: Promise<void> | null = null;

export const api = {
  async init() {
    if (booting) return booting;
    const existing = load();
    if (existing.seeded) return;
    booting = (async () => {
    const db = load();
    if (db.seeded) return;
    for (const d of DEMO) {
      const student: Student = {
        id: uid(),
        name: d.name,
        email: d.email.toLowerCase(),
        passwordHash: await hashPassword(d.password),
        usn: d.usn,
        phone: d.phone,
        department: d.department,
        year: d.year,
        ieeeNumber: d.ieeeNumber ?? "",
        membershipStatus: d.status ?? "none",
        societies: d.societies ?? [],
        bio: d.bio ?? "",
        createdAt: new Date().toISOString(),
      };
      db.students.push(student);
      if (d.status === "pending" || d.status === "active") {
        db.memberships.push({
          id: uid(),
          studentId: student.id,
          why: "Seeded campus roster application.",
          status: d.status === "active" ? "approved" : "pending",
          createdAt: new Date().toISOString(),
        });
      }
    }
    db.seeded = true;
    save(db);
    })();
    await booting;
  },

  auth: {
    async register(input: RegisterInput) {
      await api.init();
      const db = load();
      const email = input.email.trim().toLowerCase();
      if (db.students.some((s) => s.email === email)) {
        throw new Error("An account already exists for this email.");
      }
      if (db.students.some((s) => s.usn.toLowerCase() === input.usn.trim().toLowerCase())) {
        throw new Error("This USN is already on the roster.");
      }
      if (input.password.length < 6) throw new Error("Password must be at least 6 characters.");

      const student: Student = {
        id: uid(),
        name: input.name.trim(),
        email,
        passwordHash: await hashPassword(input.password),
        usn: input.usn.trim().toUpperCase(),
        phone: input.phone.trim(),
        department: input.department,
        year: input.year,
        ieeeNumber: "",
        membershipStatus: "none",
        societies: [],
        bio: "",
        createdAt: new Date().toISOString(),
      };
      db.students.push(student);
      save(db);
      setSession(student.id);
      return publicStudent(student);
    },

    async login(email: string, password: string) {
      await api.init();
      const db = load();
      const hash = await hashPassword(password);
      const student = db.students.find(
        (s) => s.email === email.trim().toLowerCase() && s.passwordHash === hash,
      );
      if (!student) throw new Error("Invalid email or password.");
      setSession(student.id);
      return publicStudent(student);
    },

    logout() {
      setSession(null);
    },

    me(): PublicStudent | null {
      const id = sessionId();
      if (!id) return null;
      const student = load().students.find((s) => s.id === id);
      return student ? publicStudent(student) : null;
    },
  },

  students: {
    get(id: string) {
      const s = load().students.find((x) => x.id === id);
      return s ? publicStudent(s) : null;
    },

    directory(): PublicStudent[] {
      return load()
        .students.filter((s) => s.membershipStatus !== "none")
        .map(publicStudent)
        .sort((a, b) => a.name.localeCompare(b.name));
    },

    update(
      id: string,
      patch: Partial<Pick<Student, "name" | "phone" | "department" | "year" | "bio" | "societies">>,
    ) {
      const db = load();
      const i = db.students.findIndex((s) => s.id === id);
      if (i < 0) throw new Error("Student not found.");
      db.students[i] = { ...db.students[i], ...patch };
      save(db);
      return publicStudent(db.students[i]);
    },

    activate(id: string, ieeeNumber: string) {
      const db = load();
      const i = db.students.findIndex((s) => s.id === id);
      if (i < 0) throw new Error("Student not found.");
      const num = normalizeIeeeNumber(ieeeNumber);
      if (!validateIeeeNumber(num)) throw new Error("Enter a valid 8–10 digit IEEE number from myIEEE.");
      db.students[i].ieeeNumber = num;
      db.students[i].membershipStatus = "active";
      db.memberships.forEach((m) => {
        if (m.studentId === id) m.status = "approved";
      });
      save(db);
      return publicStudent(db.students[i]);
    },
  },

  membership: {
    apply(studentId: string, why: string) {
      const db = load();
      const i = db.students.findIndex((s) => s.id === studentId);
      if (i < 0) throw new Error("Student not found.");
      if (db.students[i].membershipStatus === "active") {
        throw new Error("You are already an active member.");
      }
      const existing = db.memberships.find((m) => m.studentId === studentId && m.status === "pending");
      if (existing) throw new Error("A membership application is already pending.");
      const app: MembershipApp = {
        id: uid(),
        studentId,
        why: why.trim(),
        status: "pending",
        createdAt: new Date().toISOString(),
      };
      db.memberships.push(app);
      db.students[i].membershipStatus = "pending";
      save(db);
      return app;
    },

    forStudent(studentId: string) {
      return load().memberships.filter((m) => m.studentId === studentId);
    },
  },

  events: {
    register(input: { studentId: string; eventId: string; eventTitle: string; name: string; email: string }) {
      const db = load();
      const dup = db.registrations.find(
        (r) => r.eventId === input.eventId && (r.studentId === input.studentId || r.email === input.email.toLowerCase()),
      );
      if (dup) throw new Error("Already registered for this event.");
      const rec: EventRegistration = {
        id: uid(),
        studentId: input.studentId,
        eventId: input.eventId,
        eventTitle: input.eventTitle,
        name: input.name.trim(),
        email: input.email.trim().toLowerCase(),
        createdAt: new Date().toISOString(),
      };
      db.registrations.push(rec);
      save(db);
      return rec;
    },

    forStudent(studentId: string) {
      return load().registrations.filter((r) => r.studentId === studentId);
    },

    isRegistered(eventId: string, studentId?: string, email?: string) {
      return load().registrations.some(
        (r) =>
          r.eventId === eventId &&
          ((studentId && r.studentId === studentId) || (email && r.email === email.toLowerCase())),
      );
    },
  },

  messages: {
    create(input: Omit<ContactMessage, "id" | "createdAt">) {
      const db = load();
      const rec: ContactMessage = { ...input, id: uid(), createdAt: new Date().toISOString() };
      db.messages.push(rec);
      save(db);
      return rec;
    },
  },
};
