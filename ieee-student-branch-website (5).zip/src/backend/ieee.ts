/** Official IEEE.org endpoints — membership is completed on ieee.org, not on this campus site. */

export const IEEE = {
  home: "https://www.ieee.org/",
  join: "https://www.ieee.org/membership/join/index.html",
  joinStudent: "https://www.ieee.org/membership/join/index.html",
  createAccount:
    "https://www.ieee.org/profile/public/createwebaccount/showCreateAccount.html?sourceCode=join_unauth",
  students: "https://students.ieee.org/",
  myIeee: "https://www.ieee.org/membership/myieee.html",
  benefits: "https://www.ieee.org/membership/benefits/index.html",
  catalog: "https://www.ieee.org/membership-catalog/index.html",
  xplore: "https://ieeexplore.ieee.org/",
  collabratec: "https://ieee-collabratec.ieee.org/",
  spectrum: "https://spectrum.ieee.org/",
  spectrumRss: "https://spectrum.ieee.org/feeds/feed.rss",
  bangalore: "https://ieeebangalore.org/",
  r10: "https://www.ieeer10.org/",
  wie: "https://wie.ieee.org/",
  sight: "https://sight.ieee.org/",
  awards: "https://www.ieee.org/membership/students/awards/index.html",
  geoSearch: "https://www.ieee.org/communities/forms_petitions/geo_search_form.html",
  societies: {
    cs: "https://www.computer.org/",
    pes: "https://www.ieee-pes.org/",
    ras: "https://www.ieee-ras.org/",
    comsoc: "https://www.comsoc.org/",
    cas: "https://ieee-cas.org/",
    ias: "https://ias.ieee.org/",
  },
};

export const IEEE_LINKS = [
  { label: "IEEE.org", href: IEEE.home },
  { label: "Join as Student", href: IEEE.joinStudent },
  { label: "IEEE Xplore", href: IEEE.xplore },
  { label: "IEEE Bangalore Section", href: IEEE.bangalore },
  { label: "Region 10 — Asia Pacific", href: IEEE.r10 },
  { label: "Collabratec", href: IEEE.collabratec },
  { label: "IEEE Spectrum", href: IEEE.spectrum },
  { label: "myIEEE", href: IEEE.myIeee },
];

export const IEEE_JOIN_STEPS = [
  {
    title: "Create an IEEE account",
    text: "Open IEEE.org and create a web account with your college email.",
    href: IEEE.createAccount,
  },
  {
    title: "Join as a Student Member",
    text: "Select Join as a Student. Choose RajaRajeswari College of Engineering, Bengaluru when asked for school. You will be attached to IEEE Bangalore Section.",
    href: IEEE.joinStudent,
  },
  {
    title: "Pay student dues on IEEE.org",
    text: "Dues are billed by IEEE in USD (Region 10 student rate). Optional society add-ons (CS, PES, RAS, WIE) are selected in the IEEE catalog.",
    href: IEEE.catalog,
  },
  {
    title: "Copy your IEEE member number",
    text: "After payment, myIEEE shows an 8–10 digit member number. Paste it in the RRCE student portal to activate the campus roster.",
    href: IEEE.myIeee,
  },
];

export function openIeeeJoin() {
  window.open(IEEE.joinStudent, "_blank", "noopener,noreferrer");
}

export function normalizeIeeeNumber(value: string) {
  return value.replace(/\s/g, "");
}

export function validateIeeeNumber(value: string) {
  return /^\d{8,10}$/.test(normalizeIeeeNumber(value));
}

export type SpectrumItem = {
  title: string;
  link: string;
  pubDate: string;
};

export async function fetchSpectrumNews(limit = 4): Promise<SpectrumItem[]> {
  const rss = encodeURIComponent(IEEE.spectrumRss);
  const res = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${rss}`);
  if (!res.ok) throw new Error("IEEE Spectrum feed unavailable.");
  const json = (await res.json()) as {
    status?: string;
    items?: { title: string; link: string; pubDate: string }[];
  };
  if (json.status !== "ok" || !json.items) throw new Error("IEEE Spectrum feed unavailable.");
  return json.items.slice(0, limit).map((i) => ({
    title: i.title,
    link: i.link,
    pubDate: i.pubDate,
  }));
}
